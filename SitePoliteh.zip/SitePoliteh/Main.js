document.addEventListener('DOMContentLoaded', () => {
	const intro = document.querySelector('.intro');
	const header = document.querySelector('.header');
	const scrollItems = document.querySelectorAll('.services__item');

	const scrollAnimation = () => {
		let windowCenter = (window.innerHeight / 2) + window.scrollY;
		scrollItems.forEach(e1 => {
			let scrollOffset = e1.offsetTop + (e1.offsetHeight / 2);
			if (windowCenter >= scrollOffset) {
				e1.classList.add('animation-class');
			} else {
				e1.classList.remove('animation-class');
			}
		});
	};
	
	const headerFixed = () => {

		let scrollTop = window.scrollY;
		let introCenter = intro.offsetHeight / 2;
		
		if (scrollTop >= introCenter) {
			header.classList.add('fixed');
			intro.style.marginTop = '${header.offsetHeight}px';
		} else {
			header.classList.remove('fixed');
			intro.style.marginTop = '0px';	 
		}

	}

	headerFixed();
	scrollAnimation();
	window.addEventListener('scroll', () => {
		headerFixed();
		scrollAnimation();
	});
});

























/*window.onload = function() {
	//window.scrollTo(x,y)

	var scrolled;
	var timer;

	document.getElementById('top').onclick = function() {
		scrolled = window.pageYOffset;
		//window.scrollTo(0,0);
		scrollToTop();	
	}

	function scrollToTop() {
		if (scrolled < 0) {
			window.scrollTo(0, scrolled);
			scrolled = scrolled - 50;
			timer = setTimeout(scrollToTop, 200);
		}
		else {
			clearTimeout(timer);
			window.scrollTo(0,0);
		}
	}

}
*/